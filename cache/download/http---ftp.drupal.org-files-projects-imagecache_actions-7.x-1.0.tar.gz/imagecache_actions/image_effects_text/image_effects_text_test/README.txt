README
------
README for the Image effect text test module.

This module contians 2 image styles to test text effects. Additionally an image
containing a grid and a font are added.`

To make the styles work correctly, please copy the image to the public files
directory, and the font to the parent directory (root directory of the Image
Effects Tesxt module itself).  