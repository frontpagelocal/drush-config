
This directory should be used to place downloaded and custom themes
which are common to all sites. This will allow you to more easily
update Drupal core files.
